package cn.itcast.elasticsearch.service;

import java.util.List;

import org.springframework.data.domain.Pageable;

import cn.itcast.elasticsearch.domain.Article;

public interface ArticleService {

	public void saveArticle(Article article);

	public List<Article> findByContent(String content);

	public List<Article> findByContent(String content, Pageable pageable);

}
