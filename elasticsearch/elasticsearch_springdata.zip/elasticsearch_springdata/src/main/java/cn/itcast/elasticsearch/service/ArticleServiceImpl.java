package cn.itcast.elasticsearch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import cn.itcast.elasticsearch.dao.ArticleRepository;
import cn.itcast.elasticsearch.domain.Article;

@Service
public class ArticleServiceImpl implements ArticleService {
	@Autowired
	private ArticleRepository articleRepository;

	public void saveArticle(Article article) {
		articleRepository.save(article);
	}

	public List<Article> findByContent(String content) {
		return articleRepository.findByContent(content);
	}

	public List<Article> findByContent(String content, Pageable pageable) {
		return articleRepository.findByContent(content, pageable);
	}
}
