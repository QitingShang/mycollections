package cn.itcast.elasticsearch.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import cn.itcast.elasticsearch.domain.Article;

public interface ArticleRepository extends ElasticsearchRepository<Article, Integer> {

	List<Article> findByContent(String content);

	List<Article> findByContent(String content, Pageable pageable);

}
