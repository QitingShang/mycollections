package cn.itcast.elasticsearch.service.test;

import java.util.List;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHits;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cn.itcast.elasticsearch.domain.Article;
import cn.itcast.elasticsearch.service.ArticleService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class ArticleServiceTest {
	@Autowired
	private ArticleService articleService;

	@Autowired
	private Client client;

	@Autowired
	private ElasticsearchTemplate elasticsearchTemplate;

	@Before
	public void before() {
		elasticsearchTemplate.putMapping(Article.class);
	}

	@Test
	public void testSave() {
		Article article = new Article();
		article.setId(1001);
		article.setTitle("评测Transport Client vs Node Client");
		article.setContent(
				"如果你使用Java，你可能想知道什么时候用Transport Client，什么时候用Node Client。就像本书【1】最开始讨论的那样，transport client充当ES集群和你的应用直接的通信层，它知道API，并且能够在节点间自动轮循、帮你嗅探集群等等。但是它在集群外部，类似REST客户端。Node Client，另一方面，事实上是集群中的一个节点（但是不存储数据，并且不能作为主节点），由于它是一个节点，它知道整个集群的状态（全部节点都在哪，哪些分片在哪些节点上等等），这意味着它执行API时可以少用一个网络跳跃。");

		articleService.saveArticle(article);
	}

	@Test
	public void testQuery() {
		List<Article> articles = articleService.findByContent("本书");
		System.out.println(articles);
	}

	@Test
	public void testQuery2() {
		SearchResponse searchResponse = client.prepareSearch("blog").setTypes("article")
				.setQuery(QueryBuilders.termQuery("content", "讨论")).get();
		SearchHits hits = searchResponse.getHits();
		System.out.println(hits.getTotalHits());
	}

	@Test
	public void testSaveBatch() {
		for (int i = 1; i <= 100; i++) {
			Article article = new Article();
			article.setId(i);
			article.setTitle(i + "评测Transport Client vs Node Client");
			article.setContent(i
					+ "如果你使用Java，你可能想知道什么时候用Transport Client，什么时候用Node Client。就像本书【1】最开始讨论的那样，transport client充当ES集群和你的应用直接的通信层，它知道API，并且能够在节点间自动轮循、帮你嗅探集群等等。但是它在集群外部，类似REST客户端。Node Client，另一方面，事实上是集群中的一个节点（但是不存储数据，并且不能作为主节点），由于它是一个节点，它知道整个集群的状态（全部节点都在哪，哪些分片在哪些节点上等等），这意味着它执行API时可以少用一个网络跳跃。");

			articleService.saveArticle(article);
		}
	}

	@Test
	public void testPaginationQuery() {
		Pageable pageable = new PageRequest(0, 5);
		List<Article> articles = articleService.findByContent("本书", pageable);
		for (Article article : articles) {
			System.out.println(article);
		}
	}
}
